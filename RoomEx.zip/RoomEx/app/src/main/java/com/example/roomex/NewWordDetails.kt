package com.example.roomex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_new_word_details.*

class NewWordDetails : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_word_details)

        var temp: String = intent.getIntExtra("id",-1).toString()

        word_id.text = temp
        word_name.text = intent.getStringExtra("word")
    }
}

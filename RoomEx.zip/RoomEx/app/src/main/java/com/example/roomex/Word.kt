package com.example.roomex
import androidx.room.ColumnInfo

import androidx.room.Entity

import androidx.room.PrimaryKey

@Entity(tableName = "word_table")
class Word(
    @PrimaryKey(autoGenerate = true)
    var id: Int?,
    @ColumnInfo(name = "word") var word: String?

) {
    constructor() : this(0, "")
}
